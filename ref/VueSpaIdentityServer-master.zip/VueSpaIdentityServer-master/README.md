# VueSpaIdentityServer
Very simple example of Identity Server with a single page application
